var searchData=
[
  ['y',['y',['../structPoint.html#a6101960c8d2d4e8ea1d32c9234bbeb8d',1,'Point']]]
];
