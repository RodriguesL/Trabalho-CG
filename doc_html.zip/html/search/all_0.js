var searchData=
[
  ['changesize',['changeSize',['../main_8cpp.html#a33e20b37682a0492a9e95d13bef17f02',1,'main.cpp']]],
  ['click_5fcounter',['click_counter',['../geometry_8h.html#abbbd35b56259cc0cd8f6010e6a8b43e6',1,'click_counter():&#160;main.cpp'],['../main_8cpp.html#abbbd35b56259cc0cd8f6010e6a8b43e6',1,'click_counter():&#160;main.cpp']]]
];
