var searchData=
[
  ['orientationtrianglearea',['orientationTriangleArea',['../geometry_8cpp.html#a40f765016c8fc975d2f93da3bdff4ac8',1,'orientationTriangleArea(Point a, Point b, Point c):&#160;geometry.cpp'],['../geometry_8h.html#a40f765016c8fc975d2f93da3bdff4ac8',1,'orientationTriangleArea(Point a, Point b, Point c):&#160;geometry.cpp']]]
];
