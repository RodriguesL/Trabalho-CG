var searchData=
[
  ['p1',['p1',['../geometry_8h.html#ad513d6f843f1e0539132467d503e4591',1,'p1():&#160;main.cpp'],['../main_8cpp.html#ad513d6f843f1e0539132467d503e4591',1,'p1():&#160;main.cpp']]],
  ['p2',['p2',['../geometry_8h.html#a04aa64d0927f4422e811828cbe685358',1,'p2():&#160;main.cpp'],['../main_8cpp.html#a04aa64d0927f4422e811828cbe685358',1,'p2():&#160;main.cpp']]],
  ['point',['Point',['../structPoint.html',1,'']]],
  ['points',['points',['../geometry_8h.html#a0fbded2ae8aa02fc7c5011fe17fc9f06',1,'points():&#160;main.cpp'],['../main_8cpp.html#a0fbded2ae8aa02fc7c5011fe17fc9f06',1,'points():&#160;main.cpp']]]
];
