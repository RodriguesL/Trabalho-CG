var searchData=
[
  ['savepair',['savePair',['../geometry_8cpp.html#aeddf86bd2cddb215a8841b3121d8b3f8',1,'savePair(Point p1, Point p2):&#160;geometry.cpp'],['../geometry_8h.html#aeddf86bd2cddb215a8841b3121d8b3f8',1,'savePair(Point p1, Point p2):&#160;geometry.cpp']]]
];
